const { getState } = require('../state');
const { normalizeString, isGreetingText, say, calculateTotalAmount, normalizePhone } = require('../utils');
const { getUserProfile } = require('../services/supabase');
const { extractOrderDetailsWithGPT } = require('../services/openai');
const { extractLocation } = require('../services/location');
const { handleProductAddition, requestNextPhotoOrAdvance, advanceConversation } = require('../flows/salesFlow');
const { startReturnFlow, handleReturnText } = require('../flows/returnFlow');
const { handleStartCommand } = require('./commandHandler');

async function handleText(ctx) {
    const text = ctx.message?.text || "";
    if (text.startsWith("/")) return;

    const s = getState(ctx.chat.id);
    if (!s.userProfile) {
        s.userProfile = await getUserProfile(ctx.from?.username);
    }
    const normalizedText = normalizeString(text);

    if (isGreetingText(text)) {
        return handleStartCommand(ctx);
    }
    const isReturnKeyword = ["devolucion", "devolver", "registrar devolucion"].some(kw => normalizedText.includes(kw));
    if (s.returnState.currentStep !== 'initial' || isReturnKeyword) {
        if (s.returnState.currentStep === 'initial') { await startReturnFlow(ctx); } else { await handleReturnText(ctx, text); }
        return;
    }

    if (s.saleState.currentStep !== 'initial') {
        await say(ctx, "Estoy esperando otra información (como una foto o una selección de un botón). Si quieres añadir más productos, puedes hacerlo cuando termine este pedido, o empieza de nuevo con /start.");
        return;
    }

    try {
        const p = s.saleState.partialOrder;
        await say(ctx, "🧠 Analizando tu mensaje...");

        const extracted = await extractOrderDetailsWithGPT(text);
        let productsFound = false;
        let hasAmbiguousProducts = false;

        if (extracted) {
            if (extracted.customer_phone) p.customer_phone = normalizePhone(extracted.customer_phone);
            if (extracted.customer_name) p.customer_name = extracted.customer_name;
            if (extracted.notes?.length > 0) p.notes = [...new Set([...p.notes, ...extracted.notes])];
            if (extracted.time_preference) p.time_preference = extracted.time_preference;
            
            if (extracted.items?.length > 0) {
                productsFound = true;
                await say(ctx, `He encontrado ${extracted.items.length} producto(s), procesando...`);
                
                // Procesar todos los productos y acumular los que necesitan clarificación
                for (const item of extracted.items) {
                    const result = await handleProductAddition(ctx, item);
                    if (result.needsClarification) {
                        hasAmbiguousProducts = true;
                    }
                }
            }
        }

        const loc = await extractLocation(text);
        if (loc?.lat && loc?.lng) {
            p.location = loc;
            p.is_encomienda = false;
            await say(ctx, `✅ Ubicación recibida: ${loc.address}`);
        }
        
        if (productsFound) {
            // Si hay productos ambiguos, primero clarificarlos
            if (hasAmbiguousProducts) {
                await advanceConversation(ctx);
            } else {
                // Si no hay productos ambiguos, proceder con las fotos
                await requestNextPhotoOrAdvance(ctx);
            }
        } else {
            await advanceConversation(ctx);
        }

    } catch (error) {
        console.error("Error en el flujo de ventas (textHandler):", error);
        await say(ctx, "Ocurrió un error al procesar tu mensaje. Por favor, intenta de nuevo.");
    }
}

module.exports = { handleText };

