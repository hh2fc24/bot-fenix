const { getState } = require('../state');
const { reverseGeocode } = require('../services/location');
const { advanceConversation } = require('../flows/salesFlow');
const { say } = require('../utils');

async function handleLocation(ctx) {
    const s = getState(ctx.chat.id);
    const { latitude, longitude } = ctx.message?.location || {};

    if (latitude == null || longitude == null) return;

    // Solo procesar si estamos esperando una ubicación o en el estado inicial
    if (s.saleState.currentStep === "awaiting_location" || s.saleState.currentStep === "initial") {
        const geo = await reverseGeocode(latitude, longitude);
        s.saleState.partialOrder.is_encomienda = false;
        s.saleState.partialOrder.location = {
            lat: latitude,
            lng: longitude,
            address: geo.address,
            city: geo.city,
            country: geo.country,
        };
        await say(ctx, `✅ Ubicación para entrega local recibida: ${geo.address}`);
        await advanceConversation(ctx);
    }
}

module.exports = { handleLocation };
