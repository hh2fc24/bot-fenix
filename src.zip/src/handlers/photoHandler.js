const { getState } = require('../state');
const { CONSTANTS } = require('../config');
const { uploadTelegramPhotoToSupabase } = require('../services/supabase');
const { say } = require('../utils');
const { requestNextPhotoOrAdvance } = require('../flows/salesFlow');

async function handlePhoto(ctx) {
    const s = getState(ctx.chat.id);

    // La verificación correcta
    if (s.saleState.currentStep !== 'awaiting_photo' || !s.saleState.awaitingPhotoForBaseProduct) {
        return say(ctx, "He recibido una foto, pero no la esperaba ahora.");
    }

    const productName = s.saleState.awaitingPhotoForBaseProduct;
    await say(ctx, `⏳ Subiendo y asociando foto para *${productName}*...`);
    
    const url = await uploadTelegramPhotoToSupabase(ctx, CONSTANTS.BUCKETS.ORDER_IMAGES);
    if (!url) {
        return say(ctx, "❌ Hubo un error al guardar la foto. Por favor, envíala de nuevo.");
    }

    const itemToUpdate = s.saleState.partialOrder.items.find(item => item.name === productName);
    if (itemToUpdate) {
        itemToUpdate.image_url = url;
    }

    await say(ctx, `✅ Foto para *${productName}* recibida.`);

    // Limpiamos el estado de espera actual
    s.saleState.awaitingPhotoForBaseProduct = null;
    s.saleState.currentStep = 'initial'; // Crucial: reseteamos el paso

    // Dejamos que el flujo decida qué hacer a continuación (pedir la siguiente foto o avanzar)
    await requestNextPhotoOrAdvance(ctx);
}

module.exports = { handlePhoto };
